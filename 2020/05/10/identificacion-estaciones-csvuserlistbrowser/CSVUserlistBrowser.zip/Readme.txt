===========
Preparation
===========
When starting CSVUserlistBrowser.exe you will be prompted to specify the radio(s)
to be controlled. When clicking "OK" copies of the executables are created.
Please start the suitable executable for your radio.

                                   For HDSDR: HDSDR-CSVUserlistBrowser.exe
                             For ELAD FDM-S2: ELADFDM-CSVUserlistBrowser.exe
                           For WiNRADiO G305: G305-CSVUserlistBrowser.exe
                           For WiNRADiO G313: G313-CSVUserlistBrowser.exe
                           For WiNRADiO G315: G315-CSVUserlistBrowser.exe
                        For G31DDC Excalibur: G31DDC-CSVUserlistBrowser.exe
                    For G33DDC Excalibur pro: G33DDC-CSVUserlistBrowser.exe
                  For G35DDC Excalibur ultra: G35DDC-CSVUserlistBrowser.exe
                        For G39DDC Excelsior: G39DDC-CSVUserlistBrowser.exe
                            For G65DDC Sigma: G65DDC-CSVUserlistBrowser.exe
                             For Perseus SDR: PERSEUS-CSVUserlistBrowser.exe                   
                            For PowerSDR mRX: POWERSDR-CSVUserlistBrowser.exe
                                 For QTRadio: QTRADIO-CSVUserlistBrowser.exe
                            For the R2T2 GUI: R2T2-CSVUserlistBrowser.exe
                              For SDRConsole: SDRCONSOLE-CSVUserlistBrowser.exe
                            For SDRConsole 3: SDRCONSOLE3-CSVUserlistBrowser.exe
                                    For SDR#: SDRSHARP-CSVUserlistBrowser.exe
                                  For SDRuno: SDRUNO-CSVUserlistBrowser.exe
                            For SDRuno.EXTIO: SDRUNOEXTIO-CSVUserlistBrowser.exe             
                                   For SdrDx: SDRDX-CSVUserlistBrowser.exe
                      For ICOM CIV receivers: ICOM-CSVUserlistBrowser.exe
                   For Kenwood CAT receivers: KENWOOD-CSVUserlistBrowser.exe
For external rigs with Hamlib and/or Omnirig: RIG-CSVUserlistBrowser.exe

=============
CHM help file
=============
In some cases the help file (F1) seems to have no content. This is due to Microsoft's paranoia
rating files "dangerous" when they come from another computer.
Do a rightclick on CSVUserlistBrowser.chm. Select "Poperties". Next to "This file came from
another computer..." select "Unblock". The file of course is completely harmless. It does not
contain any executable code at all.

=====================
Plugin WiNRADiO users
=====================
Copy the file DF8RY-XRS-databridge.xrs from the Plugins directory to your WiNRADiO plugins directory,
normally "C:\Program Files (x86)\WiNRADiO\Plugins". Windows prompts you for administrative priviliges
because this is a system folder.

=================
Plugin SDR# users
=================
Copy the file SDRSharp.DF8RYDatabridge.dll from the Plugins folder to your SDR# application directory.
For the latest version of SDR# use the plugin from folder "New SDR# 32bit".
For older version of SDR# (e. g. 1361) use the plugin from folder "Old SDR# 1361".
Do not confuse the versions!
Open the file Plugins.xml in the SDR# application directory in a word processor (text editor)
and add the following line to the <sharpPlugins> section:
<add key="DF8RYDatabridge" value="SDRSharp.DF8RYDatabridge.DF8RYDatabridgePlugin,SDRSharp.DF8RYDatabridge" />

Please note, that "forked" and older versions of SDR# other than actually provided by
Youssef Touil on airspy.com do probably not fully support the plugin interface.
There is no warranty that the plugin will work with such versions!

Also note that the latest SDR# versions exclude several frontends from the plugin interface. 
In this case you only can track SDR#, but setting anything (like tuning a frequency) does
not work with CSVUserlistBrowser.
Currently the following frontends seem to be working:
Airspys
Spy Server
HackRF
RTL-SDRs
FUNcubes pro and pro+
SoftRock
RFSPACE SDR-IQ and Networked Radios
This is valid for SDR# 32bit.
I do not have a list of frontends which are working. Thus I cannot provide support for
other receivers.

DF8RY-XRS-databridge.xrs and SDRSharp.DF8RYDatabridge.dll (C) DF8RY are provided "as is"
without warranties of any kind.

======
Hamlib
======
If you want to use the Hamlib interface for rig and rotator control, visit
http://n0nb.users.sourceforge.net/ and download the zip package from Hamlib Win32 build
of Git master branch. Note that these are nightly builds and may contain bugs.
The current stable version of Hamlib can be found here:
https://sourceforge.net/projects/hamlib/files/hamlib/3.2/
Download the hamlib-w32 zip package.
Extract the contents
libgcc_s_sjlj-1.dll
libhamlib-2.dll (or libhamlib-4.dll)
libusb0.dll
libwinpthread-1.dll
to the _hamlib/bin directory of CSVUserlistBrowser.
Please respect the Hamlib license agreement.

=======
Omnirig
=======
Visit http://www.dxatlas.com/OmniRig/ to get the Omnirig installer and ini files
if you want to use Omnrig rig control.
