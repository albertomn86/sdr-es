The files in this folder are just backups in case you destroyed your originals.
All helper files are incorporated in the executable and are extracted when
CSVUserlistBrowser is started for the first time. Normally it is not required
to copy them explicitely.