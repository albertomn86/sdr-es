4.18 - 2019/11/01
End of beta 4.18, 4.18 final version

4.18 beta 19 - 2019/10/31
Improved: Stability when application is closed while a network download is still running

4.18 beta 18 - 2019/10/27
Fixed: URL check for new AOKI B19 URL

4.18 beta 17 - 2019/10/05
Changed: SDRSharp.DF8RYDatabridge.dll: Better adaptation of plugin background colour for SDR# skins

4.18 beta 17 - 2019/10/03
Changed: SDRSharp.DF8RYDatabridge.dll: Better readibility of text in SDR#-Plugin with new dark skinning
         Please note: This is not a full adaptation to the new skins. Please understand that
         CSVUserlistBrowser is a free time project and I must find the time to rewrite
         the code first (if ever). The SDR# skins were introduced by Youssef over night without
         warning and without further information or hints.

4.18 beta 17 - 2019/09/15
Added: In SDR# plugin: Reset RDS (X button next to PI/PSN to Clipbrd) (SDR# 1716 required)

4.18 beta 16 - 2019/09/11
Added: You can select left or right alignment of column kHz now in Options/Settings

4.18 beta 15 - 2019/09/04
Fixed: Crash when importing ILGADATA.DBF with new file structure from Sep. 1st
       Note: Due to increased files size and number of data fields the import will now take
       a bit longer. Sorry.

4.18 beta 14 - 2019/08/30
  Added: In SDR# Databridge you can copy PI code and PSN to the clipboard when an RDS signal is
       	 received (SDR# 1715 required).
Changed: General CSV converter now also accepts "dual" frequencies like 145725/145125 in the
         kHz field

4.18 beta 13 - 2019/08/29
Added: AltGr B and AltGr Shift B tune to the uplink frequency of the next/previous marker
       (if any uplink frequency is given)
Fixed: "Goto previous marker and tune" was broken in the last beta

4.18 beta 12 - 2019/08/28
Added: You can add a second frequency to the kHz field in Personal Userlists, e.g. the uplink
       frequency of an FM repeater separated by a slash. Then the field should look like this:
       145725/145125
       To tune the auxiliary frequency (the uplink) hold down the AltGr key when doubleclicking
       the line, pressing Return/Enter or pressing the left and right cursor keys.

4.18 beta 11 - 2019/08/24
Improved: Some Translation of empty (default) modulation fields for VHF frequencies outside
          OIRT and CCIR bands
 Changed: SDR# plugin SDRSharp.DF8RYDatabridge.dll no longer stores settings in 
          SDRSharp.exe.Config but uses a separate ini file instead. (Only for New SDR# 32bit)
          Please understand that the older version for Old SDR# 1361 is no longer updated.

4.18 beta 10 - 2019/08/09
Fixed: Google Earth kml file over markers sometimes listed identical frequencies 
       several times in placemarks

4.18 beta 9 - 2019/07/27
Fixed: A bug in COM ports setup when two identical ports "Off" were detected.

4.18 beta 8 - 2019/07/08
Fixed: A bug in tracking CATSync with latest Omnirig 1.19

4.18 beta 7 - 2019/07/07
Fixed: Clearing some inconsistencies in list context menus

4.18 beta 6 - 2019/06/25
Added: Support for WiNRADiO G65DDC
       Please copy new databridge DF8RY-XRS-databridge.xrs from \Plugins\WiNRADiO XRS in
       this zip package to C:\Program Files (x86)\WiNRADiO\Plugins (you will need admin
       privileges for this step to access C:\Program Files (x86)).
       Run CSVUserlistBrowser.exe and select G65DDC (WiNRADiO) in the startup screen (only
       required once). Then run G65DDC-CSVUserlistBrowser.exe from the application folder.

4.18 beta 5 - 2019/06/15
Updated: Some Enigma-Codes for Numbers & Oddities import (ODBC driver required)

4.18 beta 4 - 2019/05/11
Improved: Skipping "empty" records in SDRuno memory banks import 
          (which otherwise would show "0 KHz")
   Fixed: Path to latest s1b source directory was not properly remembered.

4.18 beta 3 - 2019/06/04
  Added: Create GoogleEarth � KML file from filtered marker list without paths
         Creates a KML file without paths, only with RX and TX location markers
  Added: Save file requester for KML output over markers
Changed: Increasing max. number of KML placemarks up to 500. Please reduce the number of
         markers yourself when the GoogleEarth map should look too much "overpopulated" ;-)
         Note: GoogleEarth only seems to open with the KML file automatically, when it is
         installed. In the portable version you must open the KML file manually.

4.18 beta 2 - 2019/06/03
Added: Import of SDRuno s1b memory banks

4.18 beta 1 - 2019/05/31
Added: Holding down Ctrl key while calling a "Show transmitter location on map" menu displays
       a marker on the map.
       Note: Not possible for Zoom Earth. Zoom Earth stores the crosshair in a cookie. There is
             no URL parameter for this. Also note that some map services no longer center the
             map position when adding a marker. In some map services the marker disappears when
             you close the search box of the website. The way how the map service handles the
             marker is not in my sphere of influence.
             Also remember: The geographical transmitter locations are not always very precise
             (except for FMSCAN lists).

Please report detailed bugs to df8ry(at)df8ry(dot)de
